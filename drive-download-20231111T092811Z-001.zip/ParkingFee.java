/**
 * @(#)a.java
 *
 *
 * @author 
 * @version 1.00 2023/10/12
 */

import java.util.Scanner;

public class ParkingFee {
 public static void main( String[] args ) {
      // Create a Scanner object for console input
    	Scanner input =new Scanner(System.in);
      
      //Declare variables
       String cartype;
       int hours;
       int fee = 0;
       
       System.out.print("Vehicle Type [private,bus,truck]?");
       cartype = input.nextLine();
       
       System.out.print("Number of hours?");
       hours = input.nextInt();
       
      switch(cartype) {
      
      	case "private":
	      	fee = hours*15;	
	      	break;
      	
      	case "bus":
	      	fee = hours*35;	
	      	break;
      	
      	case "Truck":
	     	fee = hours*50;
	     	break;
	    
	    default:
	    	System.out.println("wrong vehicle type");
    		break;
	     	
      }
      
      System.out.println("Parking fee=" +fee);
	      
 }

 }

