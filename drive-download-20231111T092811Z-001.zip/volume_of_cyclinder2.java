/**
 * @(#)vloume of cyclinder.java
 *
 *
 * @author 
 * @version 1.00 2023/10/5
 */

import java.util.Scanner;
import javax.swing.JOptionPane;

public class volume_of_cyclinder2 {

	public static void main(String[] args) {
	
    	// Create a Scanner object for console input
    	//Scanner input =new Scanner(System.in);
    	String radiusInput = JOptionPane.showInputDialog("Enter the radius of the cylinder:");
    	int radius = Integer.parseInt(radiusInput);
    	
    	
 	    String lengthInput = JOptionPane.showInputDialog("Enter the length of the cylinder:");
        int length = Integer.parseInt(lengthInput);
  		
    	
    	double volume = (Math.pow(radius, 2)*length);
   		volume =  (volume*Math.PI);//calucation
    	
    	String message = "The volume of the cylinder is: " + volume;
    	JOptionPane.showMessageDialog(null, message);
    	
   
	}
	
	
    
}