/**
 * @(#)triangle area.java
 *
 *
 * @author 
 * @version 1.00 2023/9/21
 */

import java.util.Scanner;

public class triangle_area {
	
    	public static void main(String[] args) {
    	
	    	// Create a Scanner object for console input
	    	Scanner input =new Scanner(System.in);
	    	
	    	
	    	//declear variables
	    	int width;
	    	int height;
	    	int area; //triangle area
	    		
	    	
	    	System.out.println( " This is a triangle area calculator ");
	    	System.out.print( " The Length of width is: " );
	    	width = input.nextInt(); // input an integer from keyboard to length_A
	    	
	    	System.out.print( " The Length of height is: " );
	    	height = input.nextInt(); // input an integer from keyboard to length_B
	    	
	    	 
	    	area= width * height;
	    	area= area / 2;
	    	
	    	System.out.println( " area= " + area );
	    	
    	 	
    	}
    	
    
    
    
}