import java.util.Scanner;

class RandomNumbers {
    protected int[] total;
    protected int num;

    public RandomNumbers(int num) {
        this.num = num;
        total = new int[num];
    }

    public void generateRandomNumbers() {
        for (int i = 0; i < num; i++) {
            int rand = (int) (Math.random() * 100);
            total[i] = rand;
            System.out.println(total[i]);
        }
    }

    public void calculateSum() {
        int sum = 0;
        for (int i = 0; i < num; i++) {
            sum += total[i];
        }
        System.out.println("Sum = " + sum);
    }

    public static void main(String[] args) {
        System.out.print("Number of random numbers: ");
        Scanner scanf = new Scanner(System.in);
        int num = scanf.nextInt();

        RandomNumbers randomNumbers = new RandomNumbers(num);
        randomNumbers.generateRandomNumbers();
        randomNumbers.calculateSum();
    }
}