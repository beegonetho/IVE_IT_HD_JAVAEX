import java.util.Scanner;

	public class Template {
	
 		public static void main( String[] args ) {
 			// Create a Scanner object for console input	
 			Scanner input = new Scanner(System.in);
 			
 			// Declare variables
 			double TC;
 			double HDLC;
 			double TG;
 			double LDLC;
 			
 			System.out.print( "Enter �`�x�T�J (TC) : " );
 			TC = input.nextdouble(); // input an integer from keyboard
 			
 			System.out.print( "Enter ���K���x�T�J (HDLC) " );
 			HDLC = input.nextdouble(); // input an integer from keyboard


 			System.out.print( "Enter �̪o�T� (TG) : " );
 			TG = input.nextdouble(); // input an integer from keyboard

 			LDLC = TC - HDLC - (TG/5);
 			
 			
 			

			 
			System.out.println( "�C�K���x�T�J (LDLC) = " + LDLC  );
		} 
	
	}
