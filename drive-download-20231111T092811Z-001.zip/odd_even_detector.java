/**
 * @(#)a.java
 *
 *
 * @author 
 * @version 1.00 2023/10/12
 */

import java.util.Scanner;
public class odd_even_detector {
 public static void main( String[] args ) {
      // Create a Scanner object for console input
    	Scanner input =new Scanner(System.in);
      
      //Declare variables
      int number;
      
       System.out.print("Street number?");
       number = input.nextInt();
       
      number=number%2;
      
      if (number == 1)
        System.out.println("west-bound");
      else if (number == 0) 
      	System.out.println("east-bound");
      else 
      	System.out.println("lo no");
 }

 }

