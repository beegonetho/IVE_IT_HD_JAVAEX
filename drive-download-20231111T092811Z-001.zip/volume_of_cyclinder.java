/**
 * @(#)vloume of cyclinder.java
 *
 *
 * @author 
 * @version 1.00 2023/10/5
 */

import java.util.Scanner;

public class volume_of_cyclinder {

	public static void main(String[] args) {
	
    	// Create a Scanner object for console input
    	Scanner input =new Scanner(System.in);
    	
    	
    	//declear variables
  		float radius,length,volume;
  		float volume2;
    	
    	
    	System.out.println(" v = r^2PI*l");
    	
    	
		System.out.print( " The radius of cyclinder is: " );
    	radius = (float) input.nextFloat(); //input value into total from keyboard
		
		
		System.out.print( " The Length of cyclinder is: " );
    	length = (float) input.nextFloat(); //input value into total from keyboard
		
    
    	volume = (float)(Math.pow(radius, 2)*length);
    	volume2 = (float) (volume*Math.PI);//calucation
    	
    	System.out.println( "volume of the cyclinder is:"+volume +"*pi");
    	System.out.println( "volume of the cyclinder is:"+volume2);
    	
   
	}
	
	
    
}