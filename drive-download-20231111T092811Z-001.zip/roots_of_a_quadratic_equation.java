/**
 * @(#)roots of a quadratic equation.java
 *
 *
 * @author 
 * @version 1.00 2023/10/5
 */
import javax.swing.JOptionPane;
import java.util.Scanner;

public class roots_of_a_quadratic_equation {

    public static void main(String[] args) {
    	
    	
     	// Create a Scanner object for console input
    	Scanner input =new Scanner(System.in);   	
    	
    	
    	//declear variables
  		int b,a,c;
  		double x1,x2;
  		
  		System.out.print( " a: " );
    	a =  input.nextInt(); //input value into total from keyboard
	
		System.out.print( " b: " );
    	b =  input.nextInt(); //input value into total from keyboard
			
    	System.out.print( " c: " );
    	c =  input.nextInt(); //input value into total from keyboard
		
    	x1= -b - Math.sqrt(b*b-4*a*c);
    	x1/= (2*a);
    	x2= -b + Math.sqrt(b*b-4*a*c);
    	x2/= (2*a);
    	
    	System.out.println( " x1: "+x1 );
    	
    	System.out.println( " x2: "+x2 );
    		
    		
    	
    	
    	
    	
    }
    
    
}