
 public class MultiplicationTable {
    public static void main(String[] args) {
        // Create a 2D array for the multiplication table
        int[][] mTable = new int[10][10];

        // Fill the array with multiplication table values
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                mTable[i][j] = i * j;
            }
        }

        // Print the multiplication table
        System.out.print("     ");
        for (int i = 0; i < 10; i++) {
            System.out.printf("%3d ", i);
        }
        System.out.println();
        System.out.println("   +-------------------------------");
        for (int i = 0; i < 10; i++) {
            System.out.printf("%3d |", i);
            for (int j = 0; j < 10; j++) {
                System.out.printf("%3d ", mTable[i][j]);
            }
            System.out.println();
        }
    }
}
