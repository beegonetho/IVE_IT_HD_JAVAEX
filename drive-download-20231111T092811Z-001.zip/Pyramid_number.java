import java.util.Scanner;




public class Pyramid_number {

    public static void main(String[] args) {    
    	
    	
    	Scanner input =new Scanner(System.in);
    	int i,j,num;
    		
    	System.out.print("Number?");
    	num = input.nextInt(); 
    	
    	
    	for(i = 1; i <= num; i++){
    		for(j = 1; j <= i; j++){
    			
    			System.out.print(j);
    			
    		}
    		
    		System.out.println();
    		
    	}
    	
    	   	
   	}    
}